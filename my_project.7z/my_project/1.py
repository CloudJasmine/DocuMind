from flask import Flask, jsonify, request, render_template, send_from_directory
import subprocess
import os
from pathlib import Path

app = Flask(
    __name__,
    static_folder=r'C:\Users\86157\Desktop\my_project\static',  # 静态文件路径
    template_folder=r'C:\Users\86157\Desktop\my_project\templates'  # 新增模板路径
)

# 配置conda环境路径
CONDA_ENV_PATH = Path(r"C:\Users\86157\anaconda3\envs\chat")
PYTHON_EXE = CONDA_ENV_PATH / "python.exe"
PYQSIDE_APP_PATH = Path(r"C:\Users\86157\Desktop\CLAP_Open\clap\src\CLAP\app_r12.py").resolve()  # 请确认实际路径

# 调试信息
print(f"[DEBUG] Conda Python路径: {PYTHON_EXE}")
print(f"[DEBUG] PySide应用路径: {PYQSIDE_APP_PATH}")

# 增强的验证逻辑
VALID_CREDENTIALS = {
    "admin": "password"  # 生产环境请使用加密存储
}

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username', '').strip()
    password = data.get('password', '').strip()

    if VALID_CREDENTIALS.get(username) == password:
        return jsonify({
            "status": "success",
            "message": "登录成功！",
            "start_url": "/start_pyside"  # 返回启动端点
        })
    return jsonify({"status": "error", "message": "验证失败"}), 401

@app.route('/')
def index():
    return render_template('dog.html')

@app.route('/start_pyside', methods=['GET'])
def start_pyside():
    try:
        # 使用绝对路径启动
        cmd = [
            str(PYTHON_EXE),
            str(PYQSIDE_APP_PATH)
        ]
        
        subprocess.Popen(
            cmd,
            shell=True,
            cwd=PYQSIDE_APP_PATH.parent,
            env=dict(os.environ, PATH=f"{CONDA_ENV_PATH};{os.environ['PATH']}")
        )
        
        return jsonify({
            "status": "success",
            "message": "应用已启动",
            "pid": os.getpid()
        })
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": f"启动失败: {str(e)}",
            "trace": str(PYQSIDE_APP_PATH)
        }), 500

# 静态文件路由（可选）
@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory(
        r'C:\Users\86157\Desktop\my_project\static\images', 
        filename
    )

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)  # 生产环境应关闭debug